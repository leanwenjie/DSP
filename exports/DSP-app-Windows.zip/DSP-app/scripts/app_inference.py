"""Local upload inference with frozen benchmark models; no factual verification."""
import io
import json
import threading
import time
import warnings
import numpy as np
import torch
import clip
from PIL import Image, UnidentifiedImageError
from prepare_data import ROOT, digest
from model_inference import score_saved

MODELS = ('CLIP L/14 + logistic regression', 'Logistic regression', 'CLIP similarity', 'MLP seed 42')
MAX_BYTES = 10 * 1024 * 1024
MAX_PIXELS = 20_000_000


def validate_input(content, caption):
    if not content:
        raise ValueError('Upload an image first.')
    if len(content) > MAX_BYTES:
        raise ValueError('Use an image smaller than 10 MB.')
    if not isinstance(caption, str) or not caption.strip():
        raise ValueError('Enter a caption to assess.')
    caption = caption.strip()
    if len(caption) > 4000:
        raise ValueError('Shorten the caption; CLIP accepts at most 75 text tokens.')
    try:
        clip.tokenize([caption], truncate=False)
    except RuntimeError as exc:
        raise ValueError('The caption exceeds CLIP’s 75-text-token limit. Shorten it; it will not be silently truncated.') from exc
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(content)) as source:
                if source.format not in ('JPEG', 'PNG', 'WEBP'):
                    raise ValueError('Use a JPEG, PNG or WebP image.')
                if getattr(source, 'n_frames', 1) != 1:
                    raise ValueError('Use a single still image, not an animation.')
                if source.width * source.height > MAX_PIXELS:
                    raise ValueError('Resize the image to at most 20 megapixels.')
                source.load()
                image = source.convert('RGB')
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
        raise ValueError('The image could not be decoded safely. Try another JPEG, PNG or WebP file.') from exc
    return image, caption


class Detector:
    def __init__(self):
        # ponytail: one CPU encoder is serialized; revisit only for concurrent serving.
        self.lock = threading.Lock()
        self.paths = {
            'Logistic regression': ROOT/'artifacts/logistic/best_model.npz',
            'MLP seed 42': ROOT/'artifacts/mlp/model_seed42.npz',
            'CLIP similarity': ROOT/'reports/baseline/metrics.json',
        }
        self.paths[MODELS[0]] = ROOT/'artifacts/backbones/ViT-L-14/best_model.npz'
        manifest = ROOT/'reports/newsclippings_test/frozen_manifest.json'
        try:
            self.hashes = json.loads(manifest.read_text())['sha256']
            self.hashes.update(json.loads((ROOT/'reports/backbone_evaluation/frozen_manifest.json').read_text())['sha256'])
            metrics_path = ROOT/'reports/backbone_comparison/ViT-L-14/metrics.json'
            self.verify(metrics_path)
            self.cosine_threshold = float(json.loads(metrics_path.read_text())['similarity']['threshold'])
            for path in self.paths.values():
                self.verify(path)
        except (OSError, KeyError) as exc:
            raise RuntimeError('Frozen model files are missing. Restore the project model artifacts before starting inference.') from exc
        torch.set_num_threads(2)
        self.backbone = None
        self.model = None

    def verify(self, path):
        if digest(path) != self.hashes[str(path.relative_to(ROOT))]:
            raise RuntimeError('A frozen model file has changed. Restore the evaluated artifact before inference.')

    def classify_vectors(self, vectors, model_name):
        if model_name not in MODELS:
            raise ValueError('Unknown model.')
        path = self.paths[model_name]
        self.verify(path)
        if model_name == 'CLIP similarity':
            cosine = float(np.einsum('ij,ij->i', *vectors, dtype=np.float64)[0])
            threshold = float(json.loads(path.read_text())['threshold'])
            return cosine, threshold, cosine < threshold, 'cosine similarity', 'below'
        with np.load(path, allow_pickle=False) as saved:
            score = float(score_saved(vectors, saved)[0])
            threshold = -float(saved['threshold'])
        score_type = 'sigmoid score (uncalibrated)' if model_name == 'MLP seed 42' else 'decision score'
        return score, threshold, score > threshold, score_type, 'above'

    def predict(self, image, caption, model_name):
        if model_name not in MODELS:
            raise ValueError('Unknown model.')
        with self.lock, torch.inference_mode():
            backbone = 'ViT-L/14' if model_name == MODELS[0] else 'ViT-B/32'
            if backbone != self.backbone:
                self.model = None
                self.model, self.preprocess = clip.load(backbone, device='cpu', jit=False, download_root=str(ROOT/'artifacts/clip'))
                self.model.eval()
                self.backbone = backbone
            started = time.perf_counter()
            v = self.model.encode_image(self.preprocess(image).unsqueeze(0)).float().numpy()
            t = self.model.encode_text(clip.tokenize([caption], truncate=False)).float().numpy()
            vectors = []
            for a in (v,t):
                norm = np.linalg.norm(a,axis=1,keepdims=True)
                if not np.isfinite(a).all() or np.any(norm==0):
                    raise RuntimeError('The encoder returned invalid features.')
                vectors.append(a/norm)
            result = self.screen_vectors(vectors, model_name)
        return dict(**result, seconds=time.perf_counter()-started)

    def screen_vectors(self, vectors, model_name):
        """One screening decision; retain the historical classifier for research parity."""
        score, threshold, flagged, score_type, direction = self.classify_vectors(vectors, model_name)
        cosine = float(np.einsum('ij,ij->i', *vectors, dtype=np.float64)[0])
        unified = model_name == MODELS[0]
        return dict(model=model_name, flagged=bool(flagged or (unified and cosine < self.cosine_threshold)),
                    classifier_flagged=bool(flagged), score=score, threshold=threshold,
                    score_type=score_type, flag_when=direction, cosine=cosine,
                    cosine_threshold=self.cosine_threshold if unified else None, unified=unified)
