@echo off
setlocal
cd /d "%~dp0"
py -3.12 --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.12 was not found. Install Python 3.12 with the Python launcher, then try again.
  goto failed
)
git --version >nul 2>&1
if errorlevel 1 (
  echo Git was not found. Install Git for Windows and reopen this script.
  goto failed
)
if not exist ".venv\Scripts\python.exe" (
  py -3.12 -m venv .venv
  if errorlevel 1 goto failed
)
.venv\Scripts\python.exe -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements-app.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip check
if errorlevel 1 goto failed
echo.
echo Installation complete. Double-click start_app.bat to launch the app.
pause
exit /b 0
:failed
echo.
echo Setup failed. Keep the error above and share it for troubleshooting.
pause
exit /b 1
